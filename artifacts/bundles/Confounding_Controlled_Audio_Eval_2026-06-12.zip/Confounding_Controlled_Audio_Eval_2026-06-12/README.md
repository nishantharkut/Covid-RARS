# Confounding-Controlled Audio Evaluation

Date: 2026-06-12

This bundle contains inverse-probability weighted evaluation of the quality-weighted Coswara audio fusion model after controlling for metadata/protocol covariates:
recording_date, country, age, gender, duration_sec, sample_rate_original, quality_flag.

Main result:
- Unweighted AUROC: 0.879
- IPW-controlled AUROC: 0.780
- Unweighted AUPRC: 0.832
- IPW-controlled AUPRC: 0.537
- Effective sample size after weighting: 130.4 / 318

Interpretation:
Audio retains signal after control, but a substantial part of raw performance is explained by metadata/protocol confounding.
