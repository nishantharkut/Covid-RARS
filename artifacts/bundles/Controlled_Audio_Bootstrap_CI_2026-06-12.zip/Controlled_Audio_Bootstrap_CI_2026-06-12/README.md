# Controlled Audio Bootstrap Confidence Intervals

Date: 2026-06-12

This bundle contains bootstrap confidence intervals for unweighted and inverse-probability-weighted confounding-controlled audio fusion metrics.

Main result:
- Unweighted AUROC: 0.879 [0.832, 0.920]
- IPW-controlled AUROC: 0.780 [0.693, 0.860]
- Unweighted AUPRC: 0.832 [0.766, 0.890]
- IPW-controlled AUPRC: 0.537 [0.417, 0.695]
- Effective sample size for IPW estimate: 130.4 / 318

Interpretation:
Audio predictions retain signal after confounding control, but performance drops substantially after balancing metadata/protocol covariates. This supports a dataset-confounding and external-validity narrative
rather than an inflated internal-only leaderboard claim.
